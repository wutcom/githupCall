﻿namespace BMWM.CALLOFDASHBOARD.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Diagnostics;

    [Table("sc_CallOffDetail")]
    public class CallOffDetail
    {
        [Key]
        public int id { get; set; }

        public string? CallOffName { get; set; }
        public string? ProductionLine { get; set; }
        public string? Part { get; set; }
        public string? Number { get; set; }
        public string? SeriesId { get; set; }
        public string? LotId { get; set; }
        public string? ChassisNo { get; set; }
        public string? ExterrierCode { get; set; }
        public string? InterrierCode { get; set; }
        public int Seq { get; set; }

        public DateTime Created { get; set; }

    }
}
