﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BMWM.CALLOFDASHBOARD.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Diagnostics;

    [Table("sc_Supplier")]
    public partial class Supplier
    {
        
        [Key]
        [StringLength(100)]
        public string? Name { get; set; }

        [StringLength(30)]
        public string? SupplierCode { get; set; }

        public bool? IsActive { get; set; }

    }


}
