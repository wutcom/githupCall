﻿namespace BMWM.CALLOFDASHBOARD.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Diagnostics;

    [Table("sc_Delivery")]
    public partial class Delivery
    {

      
        [StringLength(100)]
        public string? Number { get; set; }

        public int? CallOffDetailId { get; set; }

        [StringLength(100)]
        public string? SupplierName { get; set; }

        public string? PartName { get; set; }
        public string? SeriesId { get; set; }
         
        public string? LotId { get; set; }
        public string? ProductionLine { get; set; }

        public int? Qty  { get; set; }

        public DateTime? OrderDate { get; set; }
        [NotMapped]
        public string? OrderDateStr { get; set; }
        public DateTime? DeliveryDate { get; set; }
        [NotMapped]
        public string? DeliveryDateStr { get; set; }
        public DateTime? Received { get; set; }
        public string? ReceivedBy { get; set; }

        public DeliveryAction Status { get; set; }
        public int? NotifyStatus { get; set; }
       
        public string? SentBy { get; set; }
        public DateTime? SentDate { get; set; }
        [NotMapped]
        public string? SentDateStr { get; set; }
    }
    public enum DeliveryAction
    {
        Pending = 1,
        Closed = 2
    }

}
