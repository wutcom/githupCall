﻿using BMWM.CALLOFDASHBOARD.Models;
using BMWT.AUTHENTICATION.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BMWM.CALLOFDASHBOARD.Services
{
    public class ManageService
    {
        public static Supplier GetSupplier(string supplierCode)
        {
            using (var db = new DataAccess.MANUContext())
            {
                // var delivery = new Models.User();
                //var obj = db.Users.Include(e => e.UserItems).Include(e => e.UserRoles).Where(e => e.Id == userId).FirstOrDefault();
                var supplier = db.Suppliers.Where(e => e.SupplierCode == supplierCode && e.IsActive == true).FirstOrDefault();
                 

                return supplier;
            }
        }
    }
}

 