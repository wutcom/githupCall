﻿using BMWM.CALLOFDASHBOARD.Models;
using BMWT.AUTHENTICATION.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BMWM.CALLOFDASHBOARD.Services
{
    public  class DeliveryService
    {
        //public static List<Delivery> GetDeliveryPendingList(string supplierCode)
        //{
        //    using (var db = new DataAccess.MANUContext())
        //    {
        //       // var delivery = new Models.User();
        //        //var obj = db.Users.Include(e => e.UserItems).Include(e => e.UserRoles).Where(e => e.Id == userId).FirstOrDefault();
        //      var supplier = db.Suppliers.Where(e => e.SupplierCode == supplierCode && e.IsActive == true).FirstOrDefault();
        //      var delivery = db.Deliveries.Where(e => e.Status == DeliveryAction.Pending 
        //                                         && e.SupplierName == supplier.Name).ToList();
                
        //        return delivery;
        //    }
        //}
        public static List<string> GetPartList(string supplierCode)
        {
            using (var db = new DataAccess.MANUContext())
            {
               
                var supplier = db.Suppliers.Where(e => e.SupplierCode == supplierCode && e.IsActive == true).FirstOrDefault();
                var partList = db.Deliveries.Where(e => e.Status == DeliveryAction.Pending
                                                   && e.SupplierName == supplier.Name).Select(e => e.PartName).Distinct().ToList();

                return partList;
            }
        }
        public static List<string> GetLineList(string supplierCode)
        {
            using (var db = new DataAccess.MANUContext())
            {
              
                var supplier = db.Suppliers.Where(e => e.SupplierCode == supplierCode && e.IsActive == true).FirstOrDefault();
                var ProductionLine = db.Deliveries.Where(e => e.Status == DeliveryAction.Pending
                                                   && e.SupplierName == supplier.Name).Select(e => e.ProductionLine).Distinct().ToList();

                return ProductionLine;
            }
        }
       
        public static bool SendDO(string number,string userName)
        {
            
            using (var db = new DataAccess.MANUContext())
            {
                //var delivery = db.Deliveries.Where(e => e.Status == DeliveryAction.Pending
                //                                   && e.Number.Contains(number)).FirstOrDefault();
                //delivery.SentBy = userName;
                //delivery.SentDate = DateTime.Now;
                try
                {
                    int res = db.Database.ExecuteSql($"update sc_Delivery set  SentBy = {userName},SentDate = getdate() where Number = {number}");
                 //   db.SaveChanges();
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }
        public static List<CallOffDetail> GetCallOffDetails(string number)
        {
            using (var db = new DataAccess.MANUContext())
            {
             
                var detail = db.CallOffDetails.Where(e => e.Number.Contains(number)).OrderBy(e=> e.Created);

                return detail.ToList();
            }
        }
        public static List<Delivery> GetDeliveryPendingList(string supplierCode,string? DO,string? Line,string? part)
        {
            using (var db = new DataAccess.MANUContext())
            {
             
                var supplier = db.Suppliers.Where(e => e.SupplierCode == supplierCode && e.IsActive == true).FirstOrDefault();
                var number = "";
                var productioLine = "";
                var partName = "";
                if (!string.IsNullOrEmpty(DO))
                    number = DO;
                if (!string.IsNullOrEmpty(Line))
                    productioLine = Line;
                if (!string.IsNullOrEmpty(part))
                    partName = part;

                var delivery = db.Deliveries.Where(e => e.Status == DeliveryAction.Pending
                                                   && e.SupplierName == supplier.Name && e.PartName.Contains(partName)
                                                   && e.ProductionLine.Contains(productioLine) && string.IsNullOrEmpty(e.SentBy)
                                                   && e.Number.Contains(number)).OrderBy(e=>e.DeliveryDate);

                return delivery.ToList();

            }
        }
        public static List<Delivery> GetDeliverySentList(string supplierCode, string? DO, string? Line, string? part)
        {
            using (var db = new DataAccess.MANUContext())
            {
            
                var supplier = db.Suppliers.Where(e => e.SupplierCode == supplierCode && e.IsActive == true).FirstOrDefault();
                var number = "";
                var productioLine = "";
                var partName = "";
                if (!string.IsNullOrEmpty(DO))
                    number = DO;
                if (!string.IsNullOrEmpty(Line))
                    productioLine = Line;
                if (!string.IsNullOrEmpty(part))
                    partName = part;

                var delivery = db.Deliveries.Where(e => e.Status == DeliveryAction.Pending
                                                   && e.SupplierName == supplier.Name && e.PartName.Contains(partName)
                                                   && e.ProductionLine.Contains(productioLine) && !string.IsNullOrEmpty(e.SentBy)
                                                   && e.Number.Contains(number)).OrderBy(e => e.DeliveryDate);

                return delivery.ToList();

            }
        }
    }
}
