﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Reflection;
using System.Data;
using System.Diagnostics.Metrics;
using System.Drawing.Drawing2D;
using System.ComponentModel.DataAnnotations.Schema;
using System.Reflection.Metadata;
using BMWM.CALLOFDASHBOARD;
using System.Threading.Tasks;
 
using BMWM.CALLOFDASHBOARD.Models;
using BMWT.AUTHENTICATION.Models;
namespace BMWM.CALLOFDASHBOARD.DataAccess
{
    public partial class MANUContext : DbContext
    {
        private string _defaultConnection = "";
        private IConfigurationRoot _ConfigurationRoot;

        public MANUContext()
        {
            try
            {
                this._ConfigurationRoot = new ConfigurationBuilder()
                                              .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                                              .AddJsonFile("appsettings.json")
                                              .Build();
                this._defaultConnection = this._ConfigurationRoot.GetConnectionString("THPTDB");

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public MANUContext(DbContextOptions<DbContext> options) : base(options)
        {

        }

        public MANUContext(string defaultConnection)
        {
            this._defaultConnection = this._ConfigurationRoot.GetConnectionString("THPTDB");
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // For SQL Database
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseLazyLoadingProxies().UseSqlServer(this._ConfigurationRoot.GetConnectionString("THPTDB"));
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
             modelBuilder.Entity<Delivery>().HasNoKey();
        }
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Supplier> Suppliers { get; set; }
        public virtual DbSet<Delivery> Deliveries { get; set; }
        public virtual DbSet<CallOffDetail> CallOffDetails { get; set; }
    }
}
