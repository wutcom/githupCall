/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './Pages/**/*.{html,cshtml}',
    './Views/**/*.{html,cshtml}',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

