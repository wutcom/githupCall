using BMWM.CallOfDashBoard.Web.Models;
using BMWT.AUTHENTICATION.Web;
using BMWT.AUTHENTICATION;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Text;
using Newtonsoft.Json;
using System.Text.Json;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Filters;
using System.DirectoryServices;
using Microsoft.AspNetCore.Http;
namespace BMWM.CallOfDashBoard.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
 
        private readonly IHttpContextAccessor _contextAccessor;
        private Microsoft.Extensions.Configuration.IConfiguration iConfiguration;
        private HttpContext hcontext;

        public HomeController(ILogger<HomeController> logger, IHttpContextAccessor contextAccessor)
        {
            this.iConfiguration = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            _logger = logger;
            _contextAccessor = contextAccessor;
            hcontext = _contextAccessor.HttpContext;
        }
        //public IActionResult Index()
        //{


        //    return View();
        //}

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public void SetClaimAuthorize(string Sid, string username, string Groups)
        {
            //Set Data to Session
          //  HttpContext.Session.SetString("SID", Sid);

            //Add Claim to Client
            var Id = Guid.NewGuid().ToString();
            string? SecretKey = iConfiguration["JWT:Secret"];
            string? Salt = iConfiguration["JWT:Salt"];
            int ExpireInminuts = Convert.ToInt32(iConfiguration["JWT:ExpiryInMinutes"]);
            HttpResponseMessage httpResponseMsg = null;

            // Generate JWT token
            var key = Encoding.UTF8.GetBytes(SecretKey);
            //var tokenDescriptor = new SecurityTokenDescriptor
            //{
            //    Subject = new ClaimsIdentity(new Claim[]
            //    {
            //                    new Claim("SID", Id),
            //                    new Claim(ClaimTypes.Name, username),
            //                    new Claim("cuser", username),
            //                    new Claim("groups", Groups),
            //                    new Claim("IsAuthenticated", "true"),
            //    }),
            //    IssuedAt = DateTime.Now,
            //    Expires = DateTime.Now.AddMinutes(ExpireInminuts), // Set token expiration
            //    Audience = iConfiguration["JWT:ValidAudience"],
            //    Issuer = iConfiguration["JWT:ValidIssuer"],
            //    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)

            //};
          //  var tokenHandler = new JwtSecurityTokenHandler();
          //  var token = tokenHandler.CreateToken(tokenDescriptor);
          //  var tokenString = tokenHandler.WriteToken(token);
            var userDisplayName = BMWT.AUTHENTICATION.Services.ManagerService.GetUser(username).user_name;
          //  HttpContext.Session.SetString("Token", tokenString);
            HttpContext.Session.SetString("Username", username);
            HttpContext.Session.SetString("DisplayName", userDisplayName);
            httpResponseMsg = new HttpResponseMessage(HttpStatusCode.OK);
            //End Add Claim
            ViewBag.Name = userDisplayName;
            ViewBag.Username = username;

        }

        [HttpGet]
        public async Task<IActionResult> Auth()
        {
            //Get the current claims principal
            var CUSERString = string.Empty;
            var GROUPSString = string.Empty;
            CUSERString = hcontext.Request.Headers["CUSER"].ToString().Replace("Post ", string.Empty);
            GROUPSString = hcontext.Request.Headers["GROUPS"].ToString().Replace("Post ", string.Empty);

            if (!string.IsNullOrEmpty(CUSERString))
            {
                var claims = new List<Claim>
                        {
                            new Claim("cuser", CUSERString),
                            new Claim("groups", GROUPSString),
                            new Claim("IsAuthenticated", "true"),
                        };
                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var authProperties = new AuthenticationProperties
                {
                    IsPersistent = true,
                    ExpiresUtc = DateTime.UtcNow.AddMinutes(360)
                };
                var claimsPrincipal = new ClaimsPrincipal(claimsIdentity);
                Thread.CurrentPrincipal = claimsPrincipal;
                HttpContext.User = claimsPrincipal;

                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), authProperties);

                var identity = (ClaimsPrincipal)Thread.CurrentPrincipal;
                if (identity != null)
                {
                    // Get the claims values
                    CUSERString = identity.Claims.Where(c => c.Type == "cuser")
                                       .Select(c => c.Value).SingleOrDefault();
                    GROUPSString = identity.Claims.Where(c => c.Type == "groups")
                                       .Select(c => c.Value).SingleOrDefault();
                }
            }

            //Check Authorize
            var host = $"{HttpContext.Request.Scheme}://{HttpContext.Request.Host}";
            //RedirectAuth
            var RedirectApp = AppSettingsHelper.Setting("APPSETTINGS:RedirectApp");
            string url = string.Concat(this.Request.Scheme, "://", this.Request.Host, RedirectApp, "/Home/", "Auth");
            string page = "";

            /* WebEAM*/
            string username = string.Empty;
            var chkCUSERID = AppSettingsHelper.Setting("APPSETTINGS:auth_by_cuser");
            var CIDBool = Convert.ToBoolean(chkCUSERID);
        

            //if (CIDBool)
            //{
                username = BMWT.AUTHENTICATION.Services.AuthenticationService.GetAuthorizeCUserId(CUSERString);
            //}
            

            if (string.IsNullOrEmpty(CUSERString))
            {
                var redirectMapGet = AppSettingsHelper.Setting("APPSETTINGS:RedirectMapGet");
                return Redirect(host + redirectMapGet);
            }
            else
            {
                if (BMWT.AUTHENTICATION.Web.UserAuthentication.HttpSessionAlive)
                {
                    if (BMWTHttpContext.Current.Session.GetString("redirect_page") != null)
                    {
                        page = BMWTHttpContext.Current.Session.GetString("redirect_page").ToString();
                        BMWTHttpContext.Current.Session.SetString("redirect_page", null);
                        //return Redirect(page);
                        return Redirect(url);
                    }
                    else
                    {
                        var PromptUserToChangePasswordBeforeExpire = (string.IsNullOrEmpty(AppSettingsHelper.Setting("APPSETTINGS:PromptUserToChangePasswordBeforeExpire")) ? true : false);
                        var PromptUserToChangePasswordBeforeExpireValue = Convert.ToInt32(AppSettingsHelper.Setting("APPSETTINGS:PromptUserToChangePasswordBeforeExpire"));
                        if (PromptUserToChangePasswordBeforeExpire && BMWT.AUTHENTICATION.Web.UserAuthentication.PasswordExpireInDays.HasValue && BMWT.AUTHENTICATION.Web.UserAuthentication.PasswordExpireInDays.Value <= PromptUserToChangePasswordBeforeExpireValue)
                        {
                            ViewBag.PwdExpIn = BMWT.AUTHENTICATION.Web.UserAuthentication.PasswordExpireInDays.Value;
                        }
                        ViewBag.Version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;
                        return View();
                    }
                }
                else
                {
                    var remoteIpAddress = _contextAccessor.HttpContext.Connection.RemoteIpAddress.ToString();
                    var res = BMWT.AUTHENTICATION.Web.UserAuthentication.Login(username, null, remoteIpAddress, remoteIpAddress, false, true);
                  //  var res=true;
                   // if (res.Success)
                    if (res.Success)
                    {
                        //  SetClaimAuthorize(res.AuthenticationSessionId, username, GROUPSString);

                        ////
                        ///
                       // username = CUSERString;
                        //var userDisplayName = BMWT.AUTHENTICATION.Services.ManagerService.GetUser(username).user_name;

                        //var UserId = BMWT.AUTHENTICATION.Services.ManagerService.GetUser(username);
                        ////  HttpContext.Session.SetString("Token", tokenString);
                        //HttpContext.Session.SetString("Username", username);
                        //HttpContext.Session.SetString("DisplayName", userDisplayName);
                        //// httpResponseMsg = new HttpResponseMessage(HttpStatusCode.OK);
                        ////End Add Claim
                        //ViewBag.Name = userDisplayName;
                        ViewBag.Username = username;
                       // ViewBag.SupplierCode = UserId.SupplierCode;
                        ////
                        var redirect_page = BMWTHttpContext.Current.Session.GetString("redirect_page");
                        if (redirect_page != null)
                        {
                            page = redirect_page.ToString();
                            BMWTHttpContext.Current.Session.SetString("redirect_page", null);
                            // return Redirect(page);
                            return Redirect(url);
                        }
                        else
                        {
                            // return RedirectToAction("index");
                            //   return Redirect(url);
                            return RedirectToAction("CallOffDashBoard","CallOff");
                           // return View();
                        }
                    }
                    else
                    {
                        return RedirectToAction("Unauthorized");
                    }
                }
            }
        }

        public IActionResult Unauthorized()
        {
            return RedirectToAction("Unauthorized");
           // return View();
        }
      
        // CallOffDashBoard.cshtml
        //public IActionResult CallOffDashBoard(string? DO,string? line,string? part)
        //{
        //    var CUSERString = string.Empty;
        //    var GROUPSString = string.Empty;
        //    CUSERString = hcontext.Request.Headers["CUSER"].ToString().Replace("Post ", string.Empty);
        //    //var username=HttpContext.Session.GetString("Username");
        //    var username = CUSERString;
        //    var userDisplayName = BMWT.AUTHENTICATION.Services.ManagerService.GetUser(username).user_name;

        //    var UserId = BMWT.AUTHENTICATION.Services.ManagerService.GetUser(username);
        //    var Supplier = BMWM.CALLOFDASHBOARD.Services.ManageService.GetSupplier(UserId.SupplierCode);
        //    //  HttpContext.Session.SetString("Token", tokenString);
        //    HttpContext.Session.SetString("Username", username);
        //    HttpContext.Session.SetString("DisplayName", userDisplayName);
        //    HttpContext.Session.SetString("SupplierName", Supplier.Name);
        //    // httpResponseMsg = new HttpResponseMessage(HttpStatusCode.OK);
        //    //End Add Claim
        //    ViewBag.Name = userDisplayName;
        //    ViewBag.Username = username;
        //    ViewBag.SupplierCode = UserId.SupplierCode;
        //    ViewBag.SupplierName = Supplier.Name;
        //    var deliverieList = BMWM.CALLOFDASHBOARD.Services.DeliveryService.GetDeliveryPendingList(UserId.SupplierCode,DO,line,part);
        //    var partList = BMWM.CALLOFDASHBOARD.Services.DeliveryService.GetPartList(UserId.SupplierCode);
        //    var PRODLineList = BMWM.CALLOFDASHBOARD.Services.DeliveryService.GetLineList(UserId.SupplierCode);
        //    var DashboardView = new DashboardView();
        //    DashboardView.Deliveries = deliverieList;
        //    DashboardView.part = partList;
        //    DashboardView.Line = PRODLineList;

        //    // return RedirectToAction("Unauthorized");
        //    return View(DashboardView);
        //}
        public IActionResult Index([FromQuery(Name = "redirect")] string? redirect)
        {
            _logger.LogInformation($"Index:UserAuthentication.HttpSessionAlive is {BMWT.AUTHENTICATION.Web.UserAuthentication.HttpSessionAlive}");
            //Get the current claims principal
            var CUSERString = string.Empty;
            var GROUPSString = string.Empty;
            var user = User as ClaimsPrincipal;
            var identity = user.Identity as ClaimsIdentity;
            CUSERString = identity.Name;
            GROUPSString = "";
            string username = string.Empty;

            if (!string.IsNullOrEmpty(CUSERString))
            {
                var chkCUSERID = AppSettingsHelper.Setting("APPSETTINGS:auth_by_cuser");
                var CIDBool = Convert.ToBoolean(chkCUSERID);

                //if (CIDBool)
                //{
                 username = (!string.IsNullOrEmpty(BMWT.AUTHENTICATION.Services.AuthenticationService.GetAuthorizeCUserId(CUSERString)) ? BMWT.AUTHENTICATION.Services.AuthenticationService.GetAuthorizeCUserId(CUSERString) : CUSERString); //CUser
                //}
                //else
                //{
                //   username = (!string.IsNullOrEmpty(BMWT.AUTHENTICATION.Services.AuthenticationService.GetAuthorizeId(CUSERString)) ? BMWT.AUTHENTICATION.Services.AuthenticationService.GetAuthorizeId(CUSERString) : CUSERString); //CUser
                //}
            }

            var host = $"{HttpContext.Request.Scheme}://{HttpContext.Request.Host}";
            string url = string.Concat(this.Request.Scheme, "://", this.Request.Host, "/Home/", "Index");

            string page = "";
            if (url.Contains("redirect"))
            {
                page = redirect;
                if (page.StartsWith("http"))
                    return RedirectToAction("Logout");

                BMWTHttpContext.Current.Session.SetString("redirect_page", page);
            }
           
                _logger.LogInformation($"Index: WebEAM");
                /* WebEAM*/
                if (string.IsNullOrEmpty(CUSERString))
                {
                    var redirectMapGet = AppSettingsHelper.Setting("APPSETTINGS:RedirectMapGet");
                    return Redirect(host + redirectMapGet);
                }
                else
                {
                    if (BMWT.AUTHENTICATION.Web.UserAuthentication.HttpSessionAlive)
                    {
                        if (BMWTHttpContext.Current.Session.GetString("redirect_page") != null)
                        {
                            page = BMWTHttpContext.Current.Session.GetString("redirect_page").ToString(); //Session["redirect_page"].ToString();
                            BMWTHttpContext.Current.Session.SetString("redirect_page", null);
                            return Redirect(page);
                        }
                        else
                        {
                            var PromptUserToChangePasswordBeforeExpire = (string.IsNullOrEmpty(AppSettingsHelper.Setting("APPSETTINGS:PromptUserToChangePasswordBeforeExpire")) ? true : false);
                            var PromptUserToChangePasswordBeforeExpireValue = Convert.ToInt32(AppSettingsHelper.Setting("APPSETTINGS:PromptUserToChangePasswordBeforeExpire"));
                            if (PromptUserToChangePasswordBeforeExpire && BMWT.AUTHENTICATION.Web.UserAuthentication.PasswordExpireInDays.HasValue
                                && BMWT.AUTHENTICATION.Web.UserAuthentication.PasswordExpireInDays.Value <= PromptUserToChangePasswordBeforeExpireValue)
                            {
                                ViewBag.PwdExpIn = BMWT.AUTHENTICATION.Web.UserAuthentication.PasswordExpireInDays.Value;
                            }
                            ViewBag.Version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;

                            return View();
                        }
                    }
                    else
                    {
                        var remoteIpAddress = _contextAccessor.HttpContext.Connection.RemoteIpAddress.ToString();
                      //  var res = BMWT.AUTHENTICATION.Web.UserAuthentication.Login(username, null, remoteIpAddress, remoteIpAddress, false, true);
                       var res = true;
                        if(res)// (res.Success)
                        {
                            //Set Data to Session
                            if (string.IsNullOrEmpty(HttpContext.Session.GetString("SID")))
                            {
                              //  SetClaimAuthorize(res.AuthenticationSessionId, username, GROUPSString);
                            }

                            var redirect_page = BMWTHttpContext.Current.Session.GetString("redirect_page");
                            if (redirect_page != null)
                            {
                                page = redirect_page.ToString();
                                BMWTHttpContext.Current.Session.SetString("redirect_page", null);
                                return Redirect(page);
                            }
                            else
                                return RedirectToAction("index");
                        }
                        else
                        {
                            return RedirectToAction("Unauthorized");
                        }
                    }
                }
            //}
        }
   
    
    }
}
