﻿using Microsoft.AspNetCore.Mvc;
using BMWM.CallOfDashBoard.Web.Models;
using BMWT.AUTHENTICATION.Web;
using BMWT.AUTHENTICATION;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
 
using System.Diagnostics;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Text;
using Newtonsoft.Json;
using System.Text.Json;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Filters;
using System.DirectoryServices;
using Microsoft.AspNetCore.Http;
using static System.Runtime.InteropServices.JavaScript.JSType;
using BMWM.CALLOFDASHBOARD.Models;
using BMWT.AUTHENTICATION.Models;
namespace BMWM.CallOfDashBoard.Web.Controllers
{
    public class CallOffController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly IHttpContextAccessor _contextAccessor;
        private Microsoft.Extensions.Configuration.IConfiguration iConfiguration;
        private HttpContext hcontext;

        public CallOffController(ILogger<HomeController> logger, IHttpContextAccessor contextAccessor)
        {
            this.iConfiguration = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
            _logger = logger;
            _contextAccessor = contextAccessor;
            hcontext = _contextAccessor.HttpContext;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Detail(string? number)
        {
            var res = BMWM.CALLOFDASHBOARD.Services.DeliveryService.GetCallOffDetails(number);
            
            return View(res);
        }
        public IActionResult CallOffDashBoard(string? DO, string? line, string? part)
        {
           
            var CUSERString = string.Empty;
            var GROUPSString = string.Empty;
            CUSERString = hcontext.Request.Headers["CUSER"].ToString().Replace("Post ", string.Empty);
            //var username=HttpContext.Session.GetString("Username");
            var username = CUSERString;
            var userDisplayName = BMWT.AUTHENTICATION.Services.ManagerService.GetUser(username).user_name;

            var UserId = BMWT.AUTHENTICATION.Services.ManagerService.GetUser(username);
            var Supplier = BMWM.CALLOFDASHBOARD.Services.ManageService.GetSupplier(UserId.SupplierCode);
            //  HttpContext.Session.SetString("Token", tokenString);
            HttpContext.Session.SetString("Username", username);
            HttpContext.Session.SetString("DisplayName", userDisplayName);
            HttpContext.Session.SetString("SupplierName", Supplier.Name);
            HttpContext.Session.SetString("SupplierCode", UserId.SupplierCode);
            // httpResponseMsg = new HttpResponseMessage(HttpStatusCode.OK);
            //End Add Claim
            ViewBag.Name = userDisplayName;
            ViewBag.Username = username;
            ViewBag.SupplierCode = UserId.SupplierCode;
            ViewBag.SupplierName = Supplier.Name;
            var deliverieList = BMWM.CALLOFDASHBOARD.Services.DeliveryService.GetDeliveryPendingList(UserId.SupplierCode, DO, line, part);
            var partList = BMWM.CALLOFDASHBOARD.Services.DeliveryService.GetPartList(UserId.SupplierCode);
            var PRODLineList = BMWM.CALLOFDASHBOARD.Services.DeliveryService.GetLineList(UserId.SupplierCode);
            var deliverieSentList = BMWM.CALLOFDASHBOARD.Services.DeliveryService.GetDeliverySentList(UserId.SupplierCode, DO, line, part);

            var DashboardView = new DashboardView();

            DashboardView.Deliveries = deliverieList;
            DashboardView.DeliveriesSent = deliverieSentList;
            foreach (var item in DashboardView.Deliveries)
            {
                var date = new DateTime(item.OrderDate.Value.Year, item.OrderDate.Value.Month, item.OrderDate.Value.Day, item.OrderDate.Value.Hour, item.OrderDate.Value.Minute, item.OrderDate.Value.Second);
                item.OrderDateStr = date.ToString("yyyy.MM.dd HH:mm:ss");
                var date2 = new DateTime(item.DeliveryDate.Value.Year, item.DeliveryDate.Value.Month, item.DeliveryDate.Value.Day, item.DeliveryDate.Value.Hour, item.DeliveryDate.Value.Minute, item.DeliveryDate.Value.Second);
                item.DeliveryDateStr = date2.ToString("yyyy.MM.dd HH:mm:ss");
              
                if (string.IsNullOrEmpty(item.SentBy))
                {
                    item.SentBy = "";
                }
            }
            foreach (var item in DashboardView.DeliveriesSent)
            {
                var date = new DateTime(item.OrderDate.Value.Year, item.OrderDate.Value.Month, item.OrderDate.Value.Day, item.OrderDate.Value.Hour, item.OrderDate.Value.Minute, item.OrderDate.Value.Second);
                item.OrderDateStr = date.ToString("yyyy.MM.dd HH:mm:ss");
                var date2 = new DateTime(item.DeliveryDate.Value.Year, item.DeliveryDate.Value.Month, item.DeliveryDate.Value.Day, item.DeliveryDate.Value.Hour, item.DeliveryDate.Value.Minute, item.DeliveryDate.Value.Second);
                item.DeliveryDateStr = date2.ToString("yyyy.MM.dd HH:mm:ss");
                var date3 = new DateTime(item.SentDate.Value.Year, item.SentDate.Value.Month, item.SentDate.Value.Day, item.SentDate.Value.Hour, item.SentDate.Value.Minute, item.SentDate.Value.Second);
                item.SentDateStr = date3.ToString("yyyy.MM.dd HH:mm:ss");
                if (string.IsNullOrEmpty(item.SentBy))
                {
                    item.SentBy = "";
                }
            }
            DashboardView.part = partList;
            DashboardView.Line = PRODLineList;
            //new Date(parseInt(res.d[i].OrderDate.substr(6))).toString("yyyy.MM.dd HH:mm:ss")
            // return RedirectToAction("Unauthorized");
            return View(DashboardView);
        }
        [HttpPost]
        public bool SendJob(string number)
        {
            var UserName= HttpContext.Session.GetString("Username");
            var res = BMWM.CALLOFDASHBOARD.Services.DeliveryService.SendDO(number, UserName);
            return res;
        }
        public List<Delivery> CallOffDashBoardTable(string? DO, string? line, string? part)
        {

            //var CUSERString = string.Empty;
            //var GROUPSString = string.Empty;
            //CUSERString = hcontext.Request.Headers["CUSER"].ToString().Replace("Post ", string.Empty);
            ////var username=HttpContext.Session.GetString("Username");
            //var username = CUSERString;
            //var userDisplayName = BMWT.AUTHENTICATION.Services.ManagerService.GetUser(username).user_name;

            //var UserId = BMWT.AUTHENTICATION.Services.ManagerService.GetUser(username);
            //var Supplier = BMWM.CALLOFDASHBOARD.Services.ManageService.GetSupplier(UserId.SupplierCode);
            ////  HttpContext.Session.SetString("Token", tokenString);
            //HttpContext.Session.SetString("Username", username);
            //HttpContext.Session.SetString("DisplayName", userDisplayName);
            //HttpContext.Session.SetString("SupplierName", Supplier.Name);
            //// httpResponseMsg = new HttpResponseMessage(HttpStatusCode.OK);
            ////End Add Claim
            //ViewBag.Name = userDisplayName;
            //ViewBag.Username = username;
            //ViewBag.SupplierCode = UserId.SupplierCode;
            //ViewBag.SupplierName = Supplier.Name;
            var SupplierCode = HttpContext.Session.GetString("SupplierCode");
            var deliverieList = BMWM.CALLOFDASHBOARD.Services.DeliveryService.GetDeliveryPendingList(SupplierCode, DO, line, part);
            
            foreach (var item in deliverieList)
            {
                var date = new DateTime(item.OrderDate.Value.Year, item.OrderDate.Value.Month, item.OrderDate.Value.Day, item.OrderDate.Value.Hour, item.OrderDate.Value.Minute, item.OrderDate.Value.Second);
                item.OrderDateStr = date.ToString("yyyy.MM.dd HH:mm:ss");
                var date2 = new DateTime(item.DeliveryDate.Value.Year, item.DeliveryDate.Value.Month, item.DeliveryDate.Value.Day, item.DeliveryDate.Value.Hour, item.DeliveryDate.Value.Minute, item.DeliveryDate.Value.Second);
                item.DeliveryDateStr = date2.ToString("yyyy.MM.dd HH:mm:ss");
                if (string.IsNullOrEmpty(item.SentBy))
                {
                    item.SentBy = "";
                }
            }
           
            return deliverieList;
        }
        public List<Delivery> CallOffDashBoardDeliveryTable(string? DO, string? line, string? part)
        {

          
            var SupplierCode = HttpContext.Session.GetString("SupplierCode");
            var deliverieList = BMWM.CALLOFDASHBOARD.Services.DeliveryService.GetDeliverySentList(SupplierCode, DO, line, part);

            foreach (var item in deliverieList)
            {
                var date = new DateTime(item.OrderDate.Value.Year, item.OrderDate.Value.Month, item.OrderDate.Value.Day, item.OrderDate.Value.Hour, item.OrderDate.Value.Minute, item.OrderDate.Value.Second);
                item.OrderDateStr = date.ToString("yyyy.MM.dd HH:mm:ss");
                var date2 = new DateTime(item.DeliveryDate.Value.Year, item.DeliveryDate.Value.Month, item.DeliveryDate.Value.Day, item.DeliveryDate.Value.Hour, item.DeliveryDate.Value.Minute, item.DeliveryDate.Value.Second);
                item.DeliveryDateStr = date2.ToString("yyyy.MM.dd HH:mm:ss");
                var date3 = new DateTime(item.SentDate.Value.Year, item.SentDate.Value.Month, item.SentDate.Value.Day, item.SentDate.Value.Hour, item.SentDate.Value.Minute, item.SentDate.Value.Second);
                item.SentDateStr = date3.ToString("yyyy.MM.dd HH:mm:ss");
                if (string.IsNullOrEmpty(item.SentBy))
                {
                    item.SentBy = "";
                }
            }

            return deliverieList;
        }
    }
}
