using System.Net;
using System.Runtime.ConstrainedExecution;
using System.Security.Principal;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System.Text;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using System.Data;
using Microsoft.AspNetCore.Connections;
using Microsoft.IdentityModel.Tokens;
using BMWT.AUTHENTICATION.Web;
using BMWT.AUTHENTICATION;
using Microsoft.IdentityModel.Logging;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Serialization;

namespace BMWM.CallOfDashBoard.Web
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);


            // Registers IHttpContextAccessor.
            builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            builder.Services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();

            // Start : Self referencing loop detected.
            builder.Services.AddMvc().AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.PropertyNamingPolicy = null;
                options.JsonSerializerOptions.DictionaryKeyPolicy = null;
            });

            JsonConvert.DefaultSettings = () => new JsonSerializerSettings
            {
                Formatting = Newtonsoft.Json.Formatting.Indented,
                ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
            };
            // End : Self referencing loop detected.

            // Add the netwonsoft json serialization service.
           

            builder.Services.AddSession(options =>
            {

                options.IdleTimeout = TimeSpan.FromMinutes(20);
                options.Cookie.HttpOnly = true;
                options.Cookie.SameSite = SameSiteMode.None; // or SameSiteMode.None if necessary
                options.Cookie.SecurePolicy = CookieSecurePolicy.None; // Set to None if not using HTTPS

                options.Cookie.IsEssential = true;

            });

            var provider = builder.Services.BuildServiceProvider();
            var configuration = provider.GetService<IConfiguration>();
          //  builder.Services.AddDbContext<THPTContext>(item => item.UseSqlServer(configuration.GetConnectionString("THPTDB")));


            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            var cuser = string.Empty;
            var groups = string.Empty;
            var idtoken = string.Empty;
            var clientId = string.Empty;
            // Add services to the container.
            builder.Services.AddControllersWithViews();

            builder.Services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;

                //     options.DefaultScheme = "bmwoauth";
                //  options.DefaultChallengeScheme = "oidc";
            })
                      .AddCookie(options =>
                      {
                          options.ExpireTimeSpan = TimeSpan.FromMinutes(1);
                          options.SlidingExpiration = true;
                          options.AccessDeniedPath = "/Forbidden/";
                          options.Cookie.Name = "bmwoauth";
                          options.LoginPath = "/login";
                          options.LogoutPath = "/Home/Logout";
                      })
                      .AddJwtBearer(options =>
                      {
                          options.SaveToken = true;
                          options.RequireHttpsMetadata = false;
                          options.TokenValidationParameters = new TokenValidationParameters()
                          {
                              ValidateIssuer = true,
                              ValidateAudience = true,
                              ValidateIssuerSigningKey = true,
                              ValidateLifetime = true,
                              ValidIssuer = builder.Configuration["Jwt:ValidIssuer"],
                              ValidAudience = builder.Configuration["Jwt:ValidAudience"],
                              IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Secret"])),
                              ClockSkew = TimeSpan.Zero, // Messes with expiry!
                              RequireExpirationTime = true
                          };

                          options.Events = new JwtBearerEvents()
                          {
                              OnMessageReceived = context =>
                              {
                                  if (context.Request.Headers.ContainsKey("JWTToken"))
                                  {
                                      var token = context.Request.Headers["JWTToken"].ToString();
                                      if (token.StartsWith("Bearer"))
                                      {
                                          context.Token = token.Substring(7).ToString();
                                      }
                                  }
                                  return Task.CompletedTask;
                              }
                          };
                      })
                      .AddOpenIdConnect("bmwoauth", options =>
                      {
                          options.SignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                          options.Authority = builder.Configuration["OAUTHNMW:OAUTHBMWDomain"];
                          options.ClientId = builder.Configuration["OAUTHNMW:ClientId"];
                          options.ClientSecret = builder.Configuration["OAUTHNMW:ClientSecret"];
                          options.ResponseType = OpenIdConnectResponseType.CodeIdTokenToken;
                          // options.SignedOutCallbackPath = builder.Configuration["OAUTHNMW:SignedOutCallbackPath"];
                          options.RemoteSignOutPath = builder.Configuration["OAUTHNMW:RemoteSignOutPath"];
                          options.ClaimsIssuer = builder.Configuration["OAUTHNMW:OAUTHBMWDomain"];
                          options.CallbackPath = builder.Configuration["OAUTHNMW:CallbackPath"];
                          options.SignedOutRedirectUri = builder.Configuration["OAUTHNMW:PostLogoutRedirectUri"];//test
                          options.AuthenticationMethod = OpenIdConnectRedirectBehavior.RedirectGet;
                          options.SaveTokens = true;
                          options.UseTokenLifetime = true;
                          options.GetClaimsFromUserInfoEndpoint = true;
                          options.RequireHttpsMetadata = false;
                          options.Scope.Add(OpenIdConnectScope.OpenIdProfile);
                          options.SignOutScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                          options.CorrelationCookie.SameSite = Microsoft.AspNetCore.Http.SameSiteMode.None;
                          //options.Prompt = "none";//"login";
                          options.TokenValidationParameters = new TokenValidationParameters
                          {
                              NameClaimType = "name"
                          };

                          var oidcOptions = new OpenIdConnectOptions
                          {
                              Events = new OpenIdConnectEvents()
                              {
                                  // get access token
                                  OnTicketReceived = ctx =>
                                  {
                                      // transform claims
                                      var access_token = ctx.Result.Ticket.Properties.GetTokenValue("access_token");
                                      var id_token = ctx.Result.Ticket.Properties.GetTokenValue("id_token");
                                      return Task.FromResult(0);
                                  }
                              }
                          };

                          options.Events = new OpenIdConnectEvents
                          {
                              OnTokenResponseReceived = context =>
                              {
                                  var ticket = context.ProtocolMessage.AccessToken;
                                  return Task.CompletedTask;
                              },
                              OnRemoteFailure = context =>
                              {
                                  context.Response.Redirect(builder.Configuration["OAUTHNMW:RedirectUriAuth"]);
                                  context.HandleResponse();
                                  return Task.FromResult(0);
                              },
                              OnSignedOutCallbackRedirect = (context) =>
                              {
                                  //context.ProtocolMessage.PostLogoutRedirectUri = "/Home/Logout";
                                  context.ProtocolMessage.PostLogoutRedirectUri = builder.Configuration["OAUTHNMW:RemoteSignOutPath"];
                                  return Task.CompletedTask;
                              },
                              OnUserInformationReceived = (context) =>
                              {
                                  var identity = (ClaimsIdentity)context.Principal.Identity;
                                  var fnrString = identity.FindFirst("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier")?.Value; //subname
                                  cuser = fnrString;
                                  return Task.CompletedTask;
                              },
                              OnTokenValidated = context =>
                              {
                                  idtoken = context.ProtocolMessage.IdToken;
                                  clientId = context.ProtocolMessage.ClientId;
                                  context.Properties.StoreTokens(new[] { new AuthenticationToken
                        {
                            Name = "id_token",
                            Value = context.ProtocolMessage.IdToken
                        }});
                                  return Task.CompletedTask;
                              },
                              OnTicketReceived = async ctxt =>
                              {
                                  if (ctxt.Principal.Identity is ClaimsIdentity identity)
                                  {
                                      ctxt.Principal.FindAll(x => x.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier")
                                          .ToList()
                                          .ForEach(identity.RemoveClaim);
                                  }
                                  await Task.Yield();
                              },
                              OnAuthorizationCodeReceived = async context =>
                              {
                                  ////Used This
                                  //var code = context.ProtocolMessage.Code;
                                  //string cusers = context.JwtSecurityToken.Claims.First(c => c.Type == "sub").Value;
                                  //cuser = cusers;
                                  await Task.CompletedTask;
                              },
                              OnRemoteSignOut = context =>
                              {
                                  {
                                      context.HttpContext.SignOutAsync("bmwoauth");
                                      return Task.CompletedTask;
                                  };
                              },
                              OnRedirectToIdentityProvider = n => RedirectToIdentityProvider(n),
                              OnRedirectToIdentityProviderForSignOut = n => RedirectToIdentityProviderForSignOut(n, idtoken, builder.Configuration["OAUTHNMW:ClientId"], builder.Configuration["OAUTHNMW:PostLogoutRedirectUri"])
                          };
                      });

            builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            builder.Services.AddTransient<IPrincipal>(provider => provider.GetService<IHttpContextAccessor>().HttpContext.User);

            // Add services to the container.
            builder.Services.AddControllersWithViews();
            builder.Services.AddRazorPages();
            builder.Services.AddHttpContextAccessor();

            var app = builder.Build();
            //AppSettingsHelper.AppSettingsConfigure(app.Services.GetRequiredService<IConfiguration>());
            AppSettingsHelper.AppSettingsConfigure(app.Services.GetRequiredService<IConfiguration>());

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                IdentityModelEventSource.ShowPII = true;
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts(); // comment for use http

            }

            app.UseCookiePolicy(new CookiePolicyOptions()
            {
                MinimumSameSitePolicy = Microsoft.AspNetCore.Http.SameSiteMode.None,
                Secure = CookieSecurePolicy.Always,
            });

            app.UseCookiePolicy();

            BMWTHttpContext.Services = app.Services;

            //Swashbuckle.AspNetCore 
          //  app.UseSwagger();
           // app.UseSwaggerUI();
          //  app.UseSerilogRequestLogging();
            //  app.UseHttpsRedirection();  // comment for use http
            app.UseStaticFiles();
            app.UseRouting();
            app.UseCors();
            app.UseSession();


            app.Use((context, next) =>
            {
                var httpContext = context.Request.HttpContext;
                var token = context.Session.GetString("Token");

                if (!string.IsNullOrEmpty(token))
                {
                    context.Request.Headers.Add("Authorization", "Bearer " + token);
                }

                if (!string.IsNullOrEmpty(cuser))
                {
                    context.Request.Headers.Add("CUSER", cuser);
                    context.Request.Headers.Add("GROUPS", "");
                }
                return next();
            });

            app.UseAuthentication();
            app.UseAuthorization();
            app.MapDefaultControllerRoute();

            //app.MapControllerRoute(
            //    name: "default",
            //    pattern: "{controller=Home}/{action=Index}/{id?}");

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "bmwoauth",
                    pattern: "{controller=Home}/{action=Index}");
                endpoints.MapRazorPages();
            });

            app.MapGet("/login", () =>
            {
                return Results.Challenge(
                new AuthenticationProperties()
                {
                    RedirectUri = builder.Configuration["OAUTHNMW:RedirectUriAuth"] //"/Home/Auth"
                },
                    authenticationSchemes: new List<string>() { "bmwoauth" }
                );
            });

            app.Run();
        }

        private static Task RedirectToIdentityProvider(RedirectContext n)
        {
            if (n.HttpContext.User.Identity.IsAuthenticated && n.ProtocolMessage.RequestType != OpenIdConnectRequestType.Logout)
            {
                n.HandleResponse();
                n.HttpContext.Response.StatusCode = (int)HttpStatusCode.Forbidden;
                //Currently returning 403
                //Could redirect somewhere else instead
                n.HttpContext.Response.Redirect(Uri.EscapeUriString("/Home/Error"));
            }

            return Task.FromResult(0);
        }
        private static Task RedirectToIdentityProviderForSignOut(RedirectContext n, string? token, string? clientId, string? PostLogoutRedirectUri)
        {
            // var builder = WebApplication.CreateBuilder(args);

            foreach (var cookie in BMWTHttpContext.Current.Request.Cookies.Keys)
            {
                CookieOptions cookieOptions = new CookieOptions();
                cookieOptions.Expires = DateTimeOffset.UtcNow.AddDays(-1);
                BMWTHttpContext.Current.Response.Cookies.Delete(cookie, cookieOptions);
            }

            var idTokenHint = token;
            if (idTokenHint != null)
            {
                n.ProtocolMessage.IdToken = idTokenHint;
                n.ProtocolMessage.IdTokenHint = idTokenHint;
                n.ProtocolMessage.ClientId = clientId; //"6917ac70-fcc8-434a-a994-6181af297f55";
                n.ProtocolMessage.PostLogoutRedirectUri = PostLogoutRedirectUri;
            }
            return Task.FromResult(0);
        }

    }
}
