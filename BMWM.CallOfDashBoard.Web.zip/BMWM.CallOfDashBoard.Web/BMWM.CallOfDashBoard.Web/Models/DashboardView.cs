﻿using BMWM.CALLOFDASHBOARD.Models;

namespace BMWM.CallOfDashBoard.Web.Models
{
    public class DashboardView
    {
        public List<string> part { get; set; }
        public List<string> Line { get; set; }
        public List<Delivery> Deliveries { get; set; }
        public List<Delivery> DeliveriesSent { get; set; }

    }
}
