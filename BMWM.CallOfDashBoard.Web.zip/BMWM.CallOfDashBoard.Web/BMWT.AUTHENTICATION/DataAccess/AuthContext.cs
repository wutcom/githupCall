﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Reflection;
using System.Data;
using System.Diagnostics.Metrics;
using System.Drawing.Drawing2D;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Reflection.Metadata;
using BMWT.AUTHENTICATION.Models;
//using static BMWT.AUTHENTICATION.Models.Json.AuthorizeUser;

namespace BMWT.AUTHENTICATION.DataAccess
{
    public partial class AuthContext : DbContext
    {
        private string _defaultConnection = "";
        private IConfigurationRoot _ConfigurationRoot;

        public AuthContext()
        {
            try
            {
                this._ConfigurationRoot = new ConfigurationBuilder()
                                              .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                                              .AddJsonFile("appsettings.json")
                                              .Build();
                this._defaultConnection = this._ConfigurationRoot.GetConnectionString("AUTH");


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public AuthContext(DbContextOptions<DbContext> options) : base(options)
        {

        }

        public AuthContext(string defaultConnection)
        {
            this._defaultConnection = this._ConfigurationRoot.GetConnectionString("THPTDB");
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // For SQL Database
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseLazyLoadingProxies().UseSqlServer(this._ConfigurationRoot.GetConnectionString("THPTDB"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<RoleItem>()
            //.HasKey(nameof(RoleItem.RoleCode), nameof(RoleItem.ItemCode));

            //modelBuilder.Entity<UserRole>()
            //.HasKey(nameof(UserRole.UserId), nameof(UserRole.RoleCode));

            //modelBuilder.Entity<UserItem>()
            //.HasKey(nameof(UserItem.UserId), nameof(UserItem.ItemCode));

            //modelBuilder.Entity<User>()
            // .HasMany(e => e.UserItems)
            // .WithOne(e => e.User)
            // .HasForeignKey(e => e.UserId)
            // .OnDelete(DeleteBehavior.SetNull);

            //modelBuilder.Entity<User>()
            // .HasMany(e => e.UserRoles)
            // .WithOne(e => e.User)
            // .HasForeignKey(e => e.UserId)
            // .OnDelete(DeleteBehavior.SetNull);

            //modelBuilder.Entity<Item>()
            // .HasMany(e => e.RoleItems)
            // .WithOne(e => e.Item)
            // .HasForeignKey(e => e.ItemCode)
            // .OnDelete(DeleteBehavior.SetNull);

            //modelBuilder.Entity<Role>()
            // .HasMany(e => e.RoleItems)
            // .WithOne(e => e.Role)
            // .HasForeignKey(e => e.RoleCode)
            // .OnDelete(DeleteBehavior.SetNull);

            //modelBuilder.Entity<ProductCatalog>()
            //    .Property(e => e.BasePoint)
            //    .HasPrecision(18, 4);

            //modelBuilder.Entity<ProductCatalog>()
            //    .Property(e => e.BonusPoint)
            //    .HasPrecision(18, 4);

            //modelBuilder.Entity<ProductCatalog>()
            //    .Property(e => e.Amount)
            //    .HasPrecision(18, 4);

            //modelBuilder.Entity<Payment>()
            //    .Property(e => e.BasePoint)
            //    .HasPrecision(18, 4);

            //modelBuilder.Entity<Payment>()
            //    .Property(e => e.BonusPoint)
            //    .HasPrecision(18, 4);

            //modelBuilder.Entity<Payment>()
            //    .Property(e => e.Amount)
            //    .HasPrecision(18, 4);

            //modelBuilder.Entity<Payment>()
            //    .Property(e => e.FiatAmount)
            //    .HasPrecision(18, 4);

            //modelBuilder.Entity<Payment>()
            //    .Property(e => e.FiatFee)
            //    .HasPrecision(18, 4);

            //modelBuilder.Entity<Payment>()
            //   .Property(e => e.FiatNetAmount)
            //   .HasPrecision(18, 4);

            //modelBuilder.Entity<Product>()
            //     .HasMany(e => e.ProductCatalogs)
            //     .WithOne(e => e.Product)
            //     .HasForeignKey(e => e.ProductId)
            //     .OnDelete(DeleteBehavior.SetNull);

            //modelBuilder.Entity<Product>()
            //     .HasMany(e => e.ServerProducts)
            //     .WithOne(e => e.Product)
            //     .HasForeignKey(e => e.ProductId)
            //     .OnDelete(DeleteBehavior.SetNull);

            //modelBuilder.Entity<Contact>()
            //    .HasMany(e => e.Opportunities)
            //    .WithOne(e => e.Contact)
            //    .OnDelete(DeleteBehavior.SetNull);

            //modelBuilder.Entity<City>().HasKey(p => new { p.Name, p.Province });
            //modelBuilder.Entity<ProductCatalog>().HasNoKey().ToView(null);
        }

        //public virtual DbSet<Item> Items { get; set; }
        //public virtual DbSet<Role> Roles { get; set; }
        //public virtual DbSet<RoleItem> RoleItems { get; set; }
        public virtual DbSet<User> Users { get; set; }
        //public virtual DbSet<UserItem> UserItems { get; set; }
        //public virtual DbSet<UserRole> UserRoles { get; set; }
        //public virtual DbSet<AuthenticationSession> AuthenticationSessions { get; set; }
        //public virtual DbSet<EventLog> EventLogs { get; set; }


    }
}
