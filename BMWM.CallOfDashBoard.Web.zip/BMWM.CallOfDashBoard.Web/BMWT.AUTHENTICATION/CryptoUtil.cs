﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace BMWT.AUTHENTICATION
{
    public class CryptoUtil
    {
        private Microsoft.Extensions.Configuration.IConfiguration iConfiguration;
        private string Salts = string.Empty;
        public CryptoUtil()
        {
            this.iConfiguration = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
        }

        public static string Base64Encode(string data)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(data);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public static string Base64Decode(string data)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(data);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

        //private static byte[] _salt = Encoding.ASCII.GetBytes(Salt);
        public static string Encrypt(string plainText)
        {
            var Salt = AppSettingsHelper.Setting("CRYPTO:Salt"); //iConfiguration["CRYPTO:Salt"];
            var SharedSecret = AppSettingsHelper.Setting("CRYPTO:SharedSecret"); //iConfiguration["CRYPTO:SharedSecret"];
            byte[] _salt = Encoding.ASCII.GetBytes(Salt);
            
            if (string.IsNullOrEmpty(plainText))
                throw new ArgumentNullException("plainText");
            string outStr = null;                       // Encrypted string to return         
            RijndaelManaged aesAlg = null;              // RijndaelManaged object used to encrypt the data.
            try
            {
                // generate the key from the shared secret and the salt             
                var key = new Rfc2898DeriveBytes(SharedSecret, _salt);
                // Create a RijndaelManaged object             
                // with the specified key and IV.             
                aesAlg = new RijndaelManaged();
                aesAlg.Key = key.GetBytes(aesAlg.KeySize / 8);
                aesAlg.IV = key.GetBytes(aesAlg.BlockSize / 8);
                // Create a decrytor to perform the stream transform.             
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
                // Create the streams used for encryption.             
                using (var msEncrypt = new MemoryStream())
                {
                    using (var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (var swEncrypt = new StreamWriter(csEncrypt))
                        {
                            //Write all data to the stream.                         
                            swEncrypt.Write(plainText);
                        }
                    }
                    outStr = Convert.ToBase64String(msEncrypt.ToArray());
                }
            }
            finally
            {
                // Clear the RijndaelManaged object.             
                if (aesAlg != null)
                    aesAlg.Clear();
            }
            // Return the encrypted bytes from the memory stream.         
            return outStr;
        }

        public static string Decrypt(string cipherText)
        {
            //var Salt = iConfiguration["CRYPTO:Salt"];
            //var SharedSecret = iConfiguration["CRYPTO:SharedSecret"];

            var Salt = AppSettingsHelper.Setting("CRYPTO:Salt"); //iConfiguration["CRYPTO:Salt"];
            var SharedSecret = AppSettingsHelper.Setting("CRYPTO:SharedSecret"); //iConfiguration["CRYPTO:SharedSecret"];
            byte[] _salt = Encoding.ASCII.GetBytes(Salt);

            if (string.IsNullOrEmpty(cipherText))
                throw new ArgumentNullException("cipherText");
            // Declare the RijndaelManaged object         
            // used to decrypt the data.         
            RijndaelManaged aesAlg = null;
            // Declare the string used to hold         
            // the decrypted text.         
            string plaintext = null;
            try
            {
                // generate the key from the shared secret and the salt             
                var key = new Rfc2898DeriveBytes(SharedSecret, _salt);
                // Create a RijndaelManaged object             
                // with the specified key and IV.             
                aesAlg = new RijndaelManaged();
                aesAlg.Key = key.GetBytes(aesAlg.KeySize / 8);
                aesAlg.IV = key.GetBytes(aesAlg.BlockSize / 8);
                // Create a decrytor to perform the stream transform.             
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
                // Create the streams used for decryption.                             
                byte[] bytes = Convert.FromBase64String(cipherText);
                using (var msDecrypt = new MemoryStream(bytes))
                {
                    using (var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (var srDecrypt = new StreamReader(csDecrypt))
                            // Read the decrypted bytes from the decrypting stream                         
                            // and place them in a string.                         
                            plaintext = srDecrypt.ReadToEnd();
                    }
                }
            }
            finally
            {
                // Clear the RijndaelManaged object.             
                if (aesAlg != null)
                    aesAlg.Clear();
            }
            return plaintext;
        }

        private static Random random = new Random();
        public static string RandomAlpha(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}