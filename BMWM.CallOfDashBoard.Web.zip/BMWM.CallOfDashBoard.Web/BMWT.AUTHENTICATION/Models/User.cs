namespace BMWT.AUTHENTICATION.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Diagnostics;

    [Table("m_user")]
    public partial class User
    {
        //public User()
        //{
        //    UserItems = new HashSet<UserItem>();
        //    UserRoles = new HashSet<UserRole>();
        //}
        [Key]
        [StringLength(20)]
        public string? user_id { get; set; }

        [StringLength(50)]
        public string? password { get; set; }

        [StringLength(100)]
        public string? LDAPUsername { get; set; }

        public UserAuthenticateBy AuthenticateBy { get; set; }

        [StringLength(50)]
        public string? user_name { get; set; }
       
        [StringLength(10)]
        public string? status { get; set; }

        [StringLength(30)]
        public string? SupplierCode { get; set; }

        public DateTime? PasswordExpireOn { get; set; }

     
    }

    public enum UserAuthenticateBy
    {
        DB = 1,
        LDAP = 2,
        CUSTOM = 3
    }
}
