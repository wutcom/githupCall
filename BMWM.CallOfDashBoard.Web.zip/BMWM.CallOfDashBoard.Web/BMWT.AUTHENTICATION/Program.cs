using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore;
using BMWT.AUTHENTICATION;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Builder;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.Net.Http.Headers;
using Microsoft.AspNetCore.Http;
using BMWT.AUTHENTICATION.DataAccess;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Identity;
using Microsoft.OpenApi.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;


var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

//// Add services to the container.
//builder.Services.AddControllersWithViews();

//// Registers IHttpContextAccessor.
//builder.Services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
//builder.Services.AddHttpContextAccessor();

//// Start : Self referencing loop detected.
//builder.Services.AddMvc().AddJsonOptions(options =>
//{
//    options.JsonSerializerOptions.PropertyNamingPolicy = null;
//    options.JsonSerializerOptions.DictionaryKeyPolicy = null;
//});

//builder.Services.AddMvc().AddRazorPagesOptions(options =>
//{
//    options.Conventions.AddPageRoute("/Home/Index", "");
//});

JsonConvert.DefaultSettings = () => new JsonSerializerSettings
{
    Formatting = Newtonsoft.Json.Formatting.Indented,
    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
};
// End : Self referencing loop detected.

//// Add the netwonsoft json serialization service.
//// Microsoft.AspNetCore.Mvc.NewtonsoftJson
//builder.Services.AddControllers().AddNewtonsoftJson(options =>
//{
//    options.SerializerSettings.ContractResolver = new DefaultContractResolver();
//});

////builder.Services.AddSession();
//builder.Services.AddSession(options =>
//{
//    options.Cookie.IsEssential = true;
//});

//var provider = builder.Services.BuildServiceProvider();
//var configuration = provider.GetService<IConfiguration>();
//builder.Services.AddDbContext<AuthContext>(item => item.UseSqlServer(configuration.GetConnectionString("THPTDB")));

////RegisteredObjects.AddConnection(typeof(MsSqlDataConnection));
////FastReport.Utils.RegisteredObjects.AddConnection(typeof(MsSqlDataConnection));

//// Swashbuckle.AspNetCore 
//builder.Services.AddEndpointsApiExplorer();
//builder.Services.AddSwaggerGen();


//// Add Default Policy : CORS (Cross-Origin Resource Sharing)
//builder.Services.AddCors(options =>
//{
//    options.AddDefaultPolicy(
//        policy =>
//        {
//            policy.AllowAnyOrigin()
//                .AllowAnyHeader()
//                .AllowAnyMethod();
//        });
//});

////Add JWT Token
//builder.Services.AddAuthentication(options =>
//{
//    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
//    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
//    options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
//})
//.AddJwtBearer(options =>
//{
//    options.SaveToken = true;
//    options.RequireHttpsMetadata = false;
//    options.TokenValidationParameters = new TokenValidationParameters()
//    {
//        ValidateIssuer = true,
//        ValidateAudience = true,
//        ValidateIssuerSigningKey = true,
//        ValidateLifetime = true,
//        ValidIssuer = builder.Configuration["Jwt:ValidIssuer"],
//        ValidAudience = builder.Configuration["Jwt:ValidAudience"],
//        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Secret"])),
//        ClockSkew = TimeSpan.Zero, // Messes with expiry!
//    };
//});


var app = builder.Build();


//// Configure the HTTP request pipeline.
//if (!app.Environment.IsDevelopment())
//{
//    app.UseExceptionHandler("/Home/Error");
//    app.UseHsts();
//}


//// Swashbuckle.AspNetCore 
//app.UseSwagger();
//app.UseSwaggerUI();

app.UseHttpsRedirection();
app.UseStaticFiles();
//app.UseFastReport();
app.UseRouting();
app.UseCors();
app.UseAuthentication();
app.UseAuthorization();
app.UseSession();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();

