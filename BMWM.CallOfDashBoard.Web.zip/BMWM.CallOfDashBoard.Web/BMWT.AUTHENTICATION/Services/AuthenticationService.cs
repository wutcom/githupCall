﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.DirectoryServices;

namespace BMWT.AUTHENTICATION.Services
{
    public static class AuthenticationService
    {
        public const string EventLogRefChangePassword = "#CHANGE_PWD";
        public const string EventLogRefLoginFail = "#LOGIN_FAIL";

        #region user
        public class LoginResult
        {
            public LoginResult()
            {
                this.Success = false;
                this.AuthenticationSessionId = null;
                this.Failure = null;
            }

            public bool Success { get; set; }
            public string AuthenticationSessionId { get; set; }
            public LoginResultFailure? Failure { get; set; }

            public enum LoginResultFailure
            {
                InvalidUserIdOrPassword,
                AccountInactive,
                AccountExpired,
                AccountBlocked,
                PasswordExpired
            }
        }

        // actualy this method use after IWA verification passed
        public static LoginResult UserBlinkLogin(string userId, string machineName, string ipAddress, bool killExistingAuthSession)
        {
            return UserBlinkLogin(userId, machineName, ipAddress, killExistingAuthSession, false);
        }
        public static LoginResult UserBlinkLogin(string userId, string machineName, string ipAddress, bool killExistingAuthSession, bool allowNotExistingUser)
        {
            var ret = new LoginResult();
            var now = DateTime.Now;
            using (var db = new DataAccess.AuthContext())
            {
                var user = db.Users.SingleOrDefault(e => e.user_id == userId);
                var loginPolicy = AppSettings.LoginPolicy;

                if (user == null && !allowNotExistingUser)
                {
                    ret.Success = false;
                    ret.Failure = LoginResult.LoginResultFailure.InvalidUserIdOrPassword;
                }
                //else if (user != null && !user.IsActive)
                //{
                //    ret.Success = false;
                //    ret.Failure = LoginResult.LoginResultFailure.AccountInactive;
                //}
                //else if (user != null && user.ExpireOn.HasValue && user.ExpireOn.Value <= now)
                //{
                //    ret.Success = false;
                //    ret.Failure = LoginResult.LoginResultFailure.AccountExpired;
                //}
                //else if (user != null && loginPolicy.FailBlock.HasValue && user.BlockOn.HasValue && (loginPolicy.FailBlock.Value.BlockSec == null || user.BlockOn.Value.AddSeconds(loginPolicy.FailBlock.Value.BlockSec.Value) >= now))
                //{
                //    ret.Success = false;
                //    ret.Failure = LoginResult.LoginResultFailure.AccountBlocked;
                //}
                else
                    ret.Success = true;


               // ret.AuthenticationSessionId = PerformLogin(ret.Success, userId, user, machineName, ipAddress, killExistingAuthSession, loginPolicy, db, now);
            }

          //  if (ret.Success) //aditional method to delete expired session if login success
              //  DeleteExpiredAuthenticationSession();

            return ret;
        }

        public static LoginResult UserLogin(string userId, string password, string machineName, string ipAddress, bool killExistingAuthSession, bool acceptExpiredPassword)
        {
            var ret = new LoginResult();
            var now = DateTime.Now;
            using (var db = new DataAccess.AuthContext())
            {
                var user = db.Users.SingleOrDefault(e => e.user_id == userId);

                Models.UserAuthenticateBy? authBy;
                if (user != null)
                {
                    authBy = user.AuthenticateBy;
                    userId = user.user_id; // correct user id case
                }
                else if (AppSettings.AllowNotExistsUserLoginViaLDAP)
                    authBy = Models.UserAuthenticateBy.LDAP;
                else
                    authBy = null;


                var loginPolicy = AppSettings.LoginPolicy;
                if (authBy.HasValue == false)
                {
                    ret.Success = false;
                    ret.Failure = LoginResult.LoginResultFailure.InvalidUserIdOrPassword;
                }
                else if (authBy.Value == Models.UserAuthenticateBy.DB) // login by db password
                {
                    try
                    {
                        if (user.status == "DISABLE")
                        {
                            ret.Success = false;
                            ret.Failure = LoginResult.LoginResultFailure.AccountInactive;
                        }
                        else if (user.PasswordExpireOn.HasValue && user.PasswordExpireOn.Value <= now)
                        {
                            ret.Success = false;
                            ret.Failure = LoginResult.LoginResultFailure.AccountExpired;
                        }
                        else if (!acceptExpiredPassword && user.PasswordExpireOn.HasValue && user.PasswordExpireOn.Value <= now)
                        {
                            ret.Success = false;
                            ret.Failure = LoginResult.LoginResultFailure.PasswordExpired;
                        }
                        else
                            ret.Success = true;
                    }
                    catch (Exception)
                    {
                        //login fail if password decrypt fail 
                        ret.Success = false;
                        ret.Failure = LoginResult.LoginResultFailure.InvalidUserIdOrPassword;
                    }
                }
             
               // ret.AuthenticationSessionId = PerformLogin(ret.Success, userId, user, machineName, ipAddress, killExistingAuthSession, loginPolicy, db, now);
            }

            //if (ret.Success) //aditional method to delete expired session if login success
            //    DeleteExpiredAuthenticationSession();

            return ret;
        }
        //private static string PerformLogin(bool success, string userId, Models.User user, string machineName, string ipAddress, bool killExistingAuthSession, LoginPolicy loginPolicy, DataAccess.AuthContext db, DateTime refDateTime)
        //{
        //    string authSid = null;
        //    if (success) // auth pass
        //    {
        //        if (killExistingAuthSession) //delete existing auth session for this user
        //            foreach (var existSession in db.AuthenticationSessions.Where(e => e.UserId == userId))
        //                db.AuthenticationSessions.Remove(existSession);

        //        //insert auth session
        //        machineName = ((machineName?.Length ?? 0) > 15 ? machineName.Substring(0, 15) : machineName);
        //        ipAddress = ((ipAddress?.Length ?? 0) > 15 ? ipAddress.Substring(0, 15) : ipAddress);
        //        var session = new Models.AuthenticationSession()
        //        {
        //            Id = Guid.NewGuid().ToString("N"),
        //            UserId = userId,
        //            UserDisplayName = user?.DisplayName,
        //            MachineName = machineName,
        //            IP = ipAddress,
        //            CreatedOn = refDateTime,
        //            LastAccessedOn = refDateTime,
        //            ExpireOn = refDateTime.AddMinutes(AppSettings.AuthenticationSessionLifetime)
        //        };
        //        db.AuthenticationSessions.Add(session);

        //        if (user != null) //update last logon info for this user
        //        {
        //            user.LastLogonOn = refDateTime;
        //            user.LastLogonMachineName = machineName;
        //            user.LastLogonIP = ipAddress;
        //            user.BlockOn = null; // clear block on
        //        }

        //        // insert event log, login success
        //        ManagerService.AddEventLog(Models.EventLog.EventLogCategory.User, userId, "Login Success", $"Machine Name: {machineName}, IP Address: {ipAddress}", userId, db);
        //        db.SaveChanges();

        //        authSid = session.Id;
        //    }
        //    else // auth fail
        //    {
        //        // insert event log, login fail
        //        ManagerService.AddEventLog(Models.EventLog.EventLogCategory.User, userId, "Login Fail", $"Machine Name: {machineName}, IP Address: {ipAddress}", null, EventLogRefLoginFail, null, db);
        //        db.SaveChanges();

        //        // check if login fail need to block
        //        if (user != null && user.AuthenticateBy != Models.UserAuthenticateBy.LDAP && !user.BlockOn.HasValue && loginPolicy.CheckFailBlock(userId, db, refDateTime))
        //        {
        //            user.BlockOn = refDateTime;
        //            ManagerService.AddEventLog(Models.EventLog.EventLogCategory.User, userId, "Block", "Block by login policy.", null, db);
        //            db.SaveChanges();
        //        }
        //    }

        //    return authSid;
        //}

        // [Obsolete("This method is obsolete. Call UserLogin in another overloading method instead.", false)]
        public static string UserLogin(string userId, string password, string machineName, string ipAddress, bool killExistingAuthSession = false)
        {
            var res = UserLogin(userId, password, machineName, ipAddress, killExistingAuthSession, true);
            return res.AuthenticationSessionId;
        }

        //private static bool LDAPAuthenticate(string user, string pass)
        //{
        //    System.DirectoryServices.DirectoryEntry de = new System.DirectoryServices.DirectoryEntry(AppSettings.LDAPPath, user, pass, System.DirectoryServices.AuthenticationTypes.Secure);
        //    try
        //    {
        //        //run a search using those credentials.  
        //        //If it returns anything, then you're authenticated
        //        System.DirectoryServices.DirectorySearcher ds = new System.DirectoryServices.DirectorySearcher(de);
        //        ds.FindOne();
        //        return true;
        //    }
        //    catch
        //    {
        //        //otherwise, it will crash out so return false
        //        return false;
        //    }
        //}
     

        public static Models.User GetUserInfo(string userId)
        {
            return ManagerService.GetUser(userId);
        }

        #endregion

        #region authentication session
        //public static void DeleteExpiredAuthenticationSession()
        //{
        //    using (var db = new DataAccess.AuthContext())
        //    {
        //        var now = DateTime.Now;
        //        foreach (var session in db.AuthenticationSessions.Where(e => e.ExpireOn <= now))
        //            db.AuthenticationSessions.Remove(session);
        //        db.SaveChanges();
        //    }
        //}
        //public static void DeleteAuthenticationSession(string authSid)
        //{
        //    using (var db = new DataAccess.AuthContext())
        //    {
        //        var obj = db.AuthenticationSessions.Find(authSid);
        //        if (obj != null)
        //        {
        //            db.AuthenticationSessions.Remove(obj);
        //            db.SaveChanges();
        //        }
        //    }
        //}
        //public static Models.AuthenticationSession GetAuthenticationSession(string authSid, bool updateTimestampInfo = true)
        //{
        //    if (AuthenticationSessionExists(authSid, updateTimestampInfo))
        //    {
        //        using (var db = new DataAccess.AuthContext())
        //        {
        //            return db.AuthenticationSessions.Find(authSid);
        //        }
        //    }
        //    else
        //    {
        //        return null;
        //    }
        //}
        //public static string SpireAuthenticationSession(string authSid, out string userId)
        //{
        //    if (AuthenticationSessionExists(authSid, false))
        //    {
        //        Models.AuthenticationSession master;
        //        using (var db = new DataAccess.AuthContext())
        //            master = db.AuthenticationSessions.Find(authSid);

        //        var user = GetUserInfo(master.UserId);
        //        userId = user.Id;
        //        return UserLogin(user.Id, user.Password, master.MachineName, master.IP, false, true).AuthenticationSessionId;
        //    }
        //    else
        //    {
        //        userId = null;
        //        return null;
        //    }
        //}
        //public static bool AuthenticationSessionExists(string authSid, bool updateTimestampInfo = true)
        //{
        //    bool res = false;
        //    using (var db = new DataAccess.AuthContext())
        //    {
        //        var obj = db.AuthenticationSessions.Find(authSid);
        //        if (obj != null)
        //        {
        //            var now = DateTime.Now;
        //            if (obj.ExpireOn <= now) //already expired
        //            {
        //                db.AuthenticationSessions.Remove(obj);
        //            }
        //            else
        //            {
        //                res = true;
        //                if (updateTimestampInfo)
        //                {
        //                    obj.LastAccessedOn = now;
        //                    obj.ExpireOn = now.AddMinutes(AppSettings.AuthenticationSessionLifetime);
        //                }
        //            }
        //            db.SaveChanges();
        //        }
        //    }
        //    return res;
        //}
        //public static bool UserAuthenticationSessionExists(string userId)
        //{
        //    using (var db = new DataAccess.AuthContext())
        //    {
        //        return db.AuthenticationSessions.Any(e => e.UserId == userId && e.ExpireOn > DateTime.Now);
        //    }
        //}
        #endregion

        #region security policy
        //public static bool StrongPasswordValidation(string password, string userId, out List<string> invalidRules)
        //{
        //    return AppSettings.StrongPasswordRules.Validate(password, userId, out invalidRules);
        //}
        //20200910 Kittinun : Add Validate wiht out connect DataBase
        public static bool StrongPasswordValidationWithOutDB(string password, string userId, out List<string> invalidRules)
        {
            return AppSettings.StrongPasswordRules.ValidateWithOutDB(password, userId, out invalidRules);
        }
        public static bool IsUserPasswordExpiredWithOutDB(DateTime PasswordExpireOn)
        {
            var d = GetPasswordExpireInDays(PasswordExpireOn);
            return d == null ? false : (d.Value <= 0);

        }
        public static bool IsUserPasswordExpired(string userId)
        {
            var d = GetUserPasswordExpireInDays(userId);
            return d == null ? false : (d.Value <= 0);
        }

        public static int? GetUserPasswordExpireInDays(string userId)
        {
            Models.UserAuthenticateBy authBy;
            DateTime? pwdExp;
            using (var db = new DataAccess.AuthContext())
            {
                var user = db.Users.Where(e => e.user_id == userId).Select(e => new { e.AuthenticateBy, e.PasswordExpireOn }).Single();
                authBy = user.AuthenticateBy;
                pwdExp = user.PasswordExpireOn;
            }
            if (authBy == Models.UserAuthenticateBy.DB)
                return GetPasswordExpireInDays(pwdExp);
            else
                return null;
        }
        internal static int? GetPasswordExpireInDays(DateTime? pwdExp)
        {
            if (pwdExp == null)
                return null;
            else
                return (pwdExp.Value.Date - DateTime.Now.Date).Days;
        }


        public class StrongPasswordRules
        {
            public struct PasswordLength
            {
                public int Minimum;
                public int Maximum;
            }
            public struct PasswordRequireCase
            {
                public char[] Cases;
                public int MeetAtLeast;
            }

            public PasswordLength? Length { get; set; }
            public PasswordRequireCase? RequireCase { get; set; }
            public bool? StartAndEndWithAlphabet { get; set; }
            public int? MinimumVarietyOfChar { get; set; }
            public bool? AllowSpace { get; set; }
            public bool? AllowUserIdAsPart { get; set; }
            public int? NotBeTopRecentPasssword { get; set; }


            //public bool Validate(string password, string userId, out List<string> invalidRules)
            //{
            //    using (var db = new DataAccess.AuthContext())
            //    {
            //        return Validate(password, userId, db, out invalidRules);
            //    }
            //}
            //public bool Validate(string password, string userId, DataAccess.AuthContext db, out List<string> invalidRules)
            //{
            //    var recentPwd = db.EventLogs.Where(e => e.Category == Models.EventLog.EventLogCategory.User
            //                                        && e.RefId == userId
            //                                        && e.Ref1 == EventLogRefChangePassword)
            //                                .OrderByDescending(e => e.CreatedOn)
            //                                .Select(e => e.Ref2)
            //                                .ToList();
            //    return Validate(password, userId, recentPwd, out invalidRules);
            //}

            //20200910 Kittinun : Add StrongPasswordValidation wiht out connect DataBase
            public bool ValidateWithOutDB(string password, string userId, out List<string> invalidRules)
            {
                if (password == null)
                    throw new ArgumentNullException(nameof(password));

                invalidRules = new List<string>();

                // length
                if (this.Length.HasValue)
                    if (password.Length < this.Length.Value.Minimum || password.Length > this.Length.Value.Maximum)
                        invalidRules.Add($"Contain from {this.Length.Value.Minimum} to {this.Length.Value.Maximum} characters");

                // require case
                if (this.RequireCase.HasValue)
                {
                    var cs = new List<string>();
                    var meet = 0;
                    foreach (var c in this.RequireCase.Value.Cases)
                    {
                        switch (c)
                        {
                            case 'U':
                                cs.Add("uppercase alphabetic");
                                if (password.Any(e => char.IsUpper(e)))
                                    meet++;
                                break;
                            case 'L':
                                cs.Add("lowercase alphabetic");
                                if (password.Any(e => char.IsLower(e)))
                                    meet++;
                                break;
                            case 'N':
                                cs.Add("numeric");
                                if (password.Any(e => char.IsDigit(e)))
                                    meet++;
                                break;
                            case 'S':
                                cs.Add("special character");
                                if (password.Any(e => !char.IsLetterOrDigit(e)))
                                    meet++;
                                break;
                        }
                    }

                    if (meet < this.RequireCase.Value.MeetAtLeast)
                    {
                        string h;
                        if (this.RequireCase.Value.MeetAtLeast < cs.Count)
                            h = $"Contain at least {this.RequireCase.Value.MeetAtLeast} of the following {cs.Count} characters: ";
                        else
                            h = "Contain all of the following characters: ";

                        invalidRules.Add(h + string.Join(", ", cs));
                    }
                }

                // begin and end with alphabet
                if (this.StartAndEndWithAlphabet.HasValue)
                    if (this.StartAndEndWithAlphabet.Value
                        && (string.IsNullOrEmpty(password) || !char.IsLetter(password[0]) || !char.IsLetter(password[password.Length - 1])))
                        invalidRules.Add($"Begin and end with an alphabetic character");

                // minimum variety of char
                if (this.MinimumVarietyOfChar.HasValue)
                    if (password.Distinct().Count() < this.MinimumVarietyOfChar.Value)
                        invalidRules.Add($"Contain at least {this.MinimumVarietyOfChar.Value} different character");

                // allow space
                if (this.AllowSpace.HasValue)
                    if (this.AllowSpace.Value == false && password.Any(e => e == ' '))
                        invalidRules.Add($"Not contain spaces");

                // allow userID as part
                if (this.AllowUserIdAsPart.HasValue)
                    if (this.AllowUserIdAsPart.Value == false && password.Contains(userId))
                        invalidRules.Add($"Not contain user ID");

                //// not be recent pwd
                //if (this.NotBeTopRecentPasssword.HasValue)
                //    if (recentPwd != null && recentPwd.Take(this.NotBeTopRecentPasssword.Value).Contains(password))
                //        invalidRules.Add($"Not be {this.NotBeTopRecentPasssword.Value} recently used password");

                return !invalidRules.Any();
            }
            public bool Validate(string password, string userId, List<string> recentPwd, out List<string> invalidRules)
            {
                if (password == null)
                    throw new ArgumentNullException(nameof(password));

                invalidRules = new List<string>();

                // length
                if (this.Length.HasValue)
                    if (password.Length < this.Length.Value.Minimum || password.Length > this.Length.Value.Maximum)
                        invalidRules.Add($"Contain from {this.Length.Value.Minimum} to {this.Length.Value.Maximum} characters");

                // require case
                if (this.RequireCase.HasValue)
                {
                    var cs = new List<string>();
                    var meet = 0;
                    foreach (var c in this.RequireCase.Value.Cases)
                    {
                        switch (c)
                        {
                            case 'U':
                                cs.Add("uppercase alphabetic");
                                if (password.Any(e => char.IsUpper(e)))
                                    meet++;
                                break;
                            case 'L':
                                cs.Add("lowercase alphabetic");
                                if (password.Any(e => char.IsLower(e)))
                                    meet++;
                                break;
                            case 'N':
                                cs.Add("numeric");
                                if (password.Any(e => char.IsDigit(e)))
                                    meet++;
                                break;
                            case 'S':
                                cs.Add("special character");
                                if (password.Any(e => !char.IsLetterOrDigit(e)))
                                    meet++;
                                break;
                        }
                    }

                    if (meet < this.RequireCase.Value.MeetAtLeast)
                    {
                        string h;
                        if (this.RequireCase.Value.MeetAtLeast < cs.Count)
                            h = $"Contain at least {this.RequireCase.Value.MeetAtLeast} of the following {cs.Count} characters: ";
                        else
                            h = "Contain all of the following characters: ";

                        invalidRules.Add(h + string.Join(", ", cs));
                    }
                }

                // begin and end with alphabet
                if (this.StartAndEndWithAlphabet.HasValue)
                    if (this.StartAndEndWithAlphabet.Value
                        && (string.IsNullOrEmpty(password) || !char.IsLetter(password[0]) || !char.IsLetter(password[password.Length - 1])))
                        invalidRules.Add($"Begin and end with an alphabetic character");

                // minimum variety of char
                if (this.MinimumVarietyOfChar.HasValue)
                    if (password.Distinct().Count() < this.MinimumVarietyOfChar.Value)
                        invalidRules.Add($"Contain at least {this.MinimumVarietyOfChar.Value} different character");

                // allow space
                if (this.AllowSpace.HasValue)
                    if (this.AllowSpace.Value == false && password.Any(e => e == ' '))
                        invalidRules.Add($"Not contain spaces");

                // allow userID as part
                if (this.AllowUserIdAsPart.HasValue)
                    if (this.AllowUserIdAsPart.Value == false && password.Contains(userId))
                        invalidRules.Add($"Not contain user ID");

                // not be recent pwd
                if (this.NotBeTopRecentPasssword.HasValue)
                    if (recentPwd != null && recentPwd.Take(this.NotBeTopRecentPasssword.Value).Contains(password))
                        invalidRules.Add($"Not be {this.NotBeTopRecentPasssword.Value} recently used password");

                return !invalidRules.Any();
            }
        }
        public class LoginPolicy
        {
            public struct LoginFailBlock
            {
                public int Times;
                public int WithinSec;
                public int? BlockSec;
            }

            public LoginFailBlock? FailBlock { get; set; }

            //public bool CheckFailBlock(string userId, DataAccess.AuthContext db, DateTime refNow)
            //{
            //    if (this.FailBlock == null)
            //        return false;

            //    var times = this.FailBlock.Value.Times;
            //    var fromDt = refNow.AddSeconds(this.FailBlock.Value.WithinSec * -1);
            //    var c = db.EventLogs.Where(e => e.Category == Models.EventLog.EventLogCategory.User
            //                       && e.RefId == userId
            //                       && e.Ref1 == EventLogRefLoginFail
            //                       && e.CreatedOn >= fromDt)
            //                       .Count();
            //    return c >= times;
            //}
        }
        #endregion security policy

        #region Authorize cnumber
        //public static string GetAuthorizeId(string userId)
        //{
        //    using (var db = new DataAccess.AuthContext())
        //    {
        //        return db.Users.Where(e => e.user_id == userId).Select(e=>e.user_id).FirstOrDefault();
        //    }
        //}
        public static string GetAuthorizeCUserId(string cnumber)
        {
            using (var db = new DataAccess.AuthContext())
            {
                return db.Users.Where(e => e.user_id == cnumber).Select(e => e.user_id).FirstOrDefault();
            }
        }
        #endregion

        #region Token
        public static string GetAuthenticatedToken(string userId, int tokenTimeOut = 1200)
        {
            if (!string.IsNullOrEmpty(userId))
                return RandomString(7) + Base64Encode(RandomString(8) + Base64Encode(DateTime.Now.AddSeconds(tokenTimeOut).Ticks.ToString("D20") + userId));
            else
                return null;
        }
        public static bool ValidateAuthenticatedToken(string userId, string token)
        {
            if (string.IsNullOrEmpty(userId) == false && string.IsNullOrEmpty(token) == false)
            {
                string decoded;
                try
                {
                    decoded = Base64Decode(Base64Decode(token.Substring(7)).Substring(8));
                }
                catch (Exception)
                {
                    return false;
                }
                var tokenValidTill = new DateTime(Convert.ToInt64(decoded.Substring(0, 20)));
                var tokenUserId = decoded.Substring(20);
                return (tokenValidTill >= DateTime.Now) && (tokenUserId.ToLower() == userId.ToLower());
            }
            else
            {
                return false;
            }
        }

        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }
        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new Random();
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
        #endregion
    }
}