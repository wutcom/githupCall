﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;

namespace BMWT.AUTHENTICATION.Services
{
    public class ManagerService
    {
        #region User
        public static Models.User GetUser(string userId)
        {
            using (var db = new DataAccess.AuthContext())
            {
                var ObjUser = new Models.User();
                //var obj = db.Users.Include(e => e.UserItems).Include(e => e.UserRoles).Where(e => e.Id == userId).FirstOrDefault();
                var obj = db.Users.Find(userId);
                if (obj != null)
                {
                    ObjUser.user_id = obj.user_id;
                    ObjUser.user_name = obj.user_name;
                    ObjUser.AuthenticateBy = obj.AuthenticateBy;
                    ObjUser.SupplierCode = obj.SupplierCode;
                  //  ObjUser.UpdatedOn = obj.UpdatedOn;
                  //  ObjUser.DisplayName = obj.DisplayName;
                 //   ObjUser.Password = DecryptPassword(obj.Password);
                }
                return ObjUser;
            }
        }
    
        #endregion End of User

        #region event log
        //internal static void AddEventLog(Models.EventLog.EventLogCategory category, string refId, string _event, string detail, string actorUserId, DataAccess.AuthContext db)
        //{
        //    AddEventLog(category, refId, _event, detail, actorUserId, null, null, db);
        //}
        //internal static void AddEventLog(Models.EventLog.EventLogCategory category, string refId, string _event, string detail, string actorUserId, string ref1, string ref2, DataAccess.AuthContext db)
        //{
        //    db.EventLogs.Add(new Models.EventLog
        //    {
        //        Category = category,
        //        RefId = refId,
        //        Event = _event,
        //        Detail = detail,
        //        ActorUserId = actorUserId,
        //        CreatedOn = DateTime.Now,
        //        Ref1 = ref1,
        //        Ref2 = ref2
        //    });
        //}
        //internal static void AddEventLog(Models.EventLog.EventLogCategory category, string refId, string _event, string detail, string actorUserId)
        //{
        //    using (var db = new DataAccess.AuthContext())
        //    {
        //        AddEventLog(category, refId, _event, detail, actorUserId, db);
        //        db.SaveChanges();
        //    }
        //}
        //internal static void AddEventLog(Models.EventLog.EventLogCategory category, string refId, string _event, string detail, string actorUserId, string ref1, string ref2)
        //{
        //    using (var db = new DataAccess.AuthContext())
        //    {
        //        AddEventLog(category, refId, _event, detail, actorUserId, ref1, ref2, db);
        //        db.SaveChanges();
        //    }
        //}

        //public static List<Models.EventLog> GetEventLogs(Models.EventLog.EventLogCategory category, string refId)
        //{
        //    using (var db = new DataAccess.AuthContext())
        //    {
        //        return db.EventLogs.Where(e => e.Category == category && e.RefId == refId).OrderByDescending(e => e.CreatedOn).ToList();
        //    }
        //}
        //public static List<Models.EventLog> GetEventLogs(Models.EventLog.EventLogCategory category, string refId, int top)
        //{
        //    using (var db = new DataAccess.AuthContext())
        //    {
        //        return db.EventLogs.Where(e => e.Category == category && e.RefId == refId).OrderByDescending(e => e.CreatedOn).Take(top).ToList();
        //    }
        //}
        #endregion event log

    }
}