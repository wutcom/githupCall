﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Net.Mail;
using Microsoft.EntityFrameworkCore;
using System.Reflection.Metadata;
using System.Xml;
using System.Net.Http.Headers;
using System.Diagnostics;
using System.IO;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace BMWT.AUTHENTICATION
{ 
    public static class AppSettingsHelper
    {
        private static IConfiguration _iConfiguration;
        public static void AppSettingsConfigure(IConfiguration config)
        {
            _iConfiguration = config;
        }
        public static string Setting(string Key)
        {
            return _iConfiguration.GetSection(Key).Value;
        }
    }
}
