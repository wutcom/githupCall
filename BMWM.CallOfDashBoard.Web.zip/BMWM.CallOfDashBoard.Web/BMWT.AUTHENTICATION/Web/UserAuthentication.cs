﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Text;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc.Core;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using Azure;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System.Data.Entity;
using Microsoft.AspNetCore.Authentication.Cookies;
using Azure.Core;

namespace BMWT.AUTHENTICATION.Web
{
    public static class SessionExtensions
    {
        public static void SetObject(this ISession session, string key, object value)
        {
            session.SetString(key, JsonConvert.SerializeObject(value));
        }

        public static T GetObject<T>(this ISession session, string key)
        {
            var value = session.GetString(key);
            return value == null ? default(T) : JsonConvert.DeserializeObject<T>(value);
        }
    }

    public static class UserAuthentication
    {
        public static bool HttpSessionAlive
        {
            get
            {
                return (BMWTHttpContext.Current.Session.GetString("auth_AuthenticationSessionId") != null);
                //return (HttpContext.Session.GetString("auth_AuthenticationSessionId") != null);
                //return (HttpContext..Current.Session["auth_AuthenticationSessionId"] != null);               
            }
        }
        public static string AuthenticationSessionId
        {
            get
            {
                return (string)BMWTHttpContext.Current.Session.GetString("auth_AuthenticationSessionId");
                //return (string)HttpContext.Current.Session["auth_AuthenticationSessionId"];
            }
        }
        public static string UserId
        {
            get
            {
                return (string)BMWTHttpContext.Current.Session.GetString("auth_UserId");
                //return (string)HttpContext.Current.Session["auth_UserId"];
            }
        }
        public static string User //Model.User
        {
            get
            {
                return (string)BMWTHttpContext.Current.Session.GetString("auth_User");

                //return (Models.User)HttpContext.Session.GetObject("auth_User") as Models.User;
                //return (Models.User)HttpContext.Current.Session["auth_User"];
            }
        }
       
        public static bool IsPasswordExpired
        {
            get
            {
                var userstring = User; //HttpContext.Session.GetString("User");
                Models.User Users = JsonConvert.DeserializeObject<Models.User>(userstring);
                if (User != null && Users.AuthenticateBy == Models.UserAuthenticateBy.DB)
                {
                    var d = Services.AuthenticationService.GetPasswordExpireInDays(Users.PasswordExpireOn);
                    return d == null ? false : (d.Value <= 0);
                }
                else
                {
                    return false;
                }

                //if (User != null && User.AuthenticateBy == Models.UserAuthenticateBy.DB)
                //{
                //    var d = Services.AuthenticationService.GetPasswordExpireInDays(User.PasswordExpireOn);
                //    return d == null ? false : (d.Value <= 0);
                //}
                //else
                //{
                //    return false;
                //}
            }
        }
        public static int? PasswordExpireInDays
        {
            get
            {
                var userstring = User; //HttpContext.Session.GetString("User");
                Models.User Users = JsonConvert.DeserializeObject<Models.User>(userstring);
                if (Users != null && Users.AuthenticateBy == Models.UserAuthenticateBy.DB)
                {
                    return Services.AuthenticationService.GetPasswordExpireInDays(Users.PasswordExpireOn);
                }
                else
                {
                    return null;
                }
            }
        }

        public static Services.AuthenticationService.LoginResult BlinkLogin(string userId, string machineName, string ipAddress, bool killExistingAuthSession, bool allowNotExistingUser = false)
        {
            var ret = Services.AuthenticationService.UserBlinkLogin(userId, machineName, ipAddress, killExistingAuthSession, allowNotExistingUser);
            if (ret.Success) //passed so, store userId in session
                SetHttpSession(ret.AuthenticationSessionId, userId);
            return ret;
        }
        public static Services.AuthenticationService.LoginResult Login(string userId, string password, string machineName, string ipAddress, bool killExistingAuthSession, bool acceptExpiredPassword)
        {
            var ret = Services.AuthenticationService.UserLogin(userId, password, machineName, ipAddress, killExistingAuthSession, acceptExpiredPassword);
           // if (ret.Success) //passed so, store userId in session
            //    SetHttpSession(ret.AuthenticationSessionId, userId);
            return ret;
        }
        //[Obsolete("This method is obsolete. Call Login in another overloading method instead.", false)]
        //public static bool Login(string userId, string password, string machineName, string ipAddress, bool killExistingAuthSession = false)
        //{
        //    string authSid = Services.AuthenticationService.UserLogin(userId, password, machineName, ipAddress, killExistingAuthSession);
        //    if (authSid != null) //passed so, store userId in session
        //        SetHttpSession(authSid, userId);
        //    return (authSid != null);
        //}
        //public static bool ContinueSession(string authSessionId)
        //{
        //    var authSession = Services.AuthenticationService.GetAuthenticationSession(authSessionId, true);
        //    if (authSession != null)
        //        SetHttpSession(authSession.Id, authSession.UserId);
        //    return (authSession != null);
        //}
        //public static bool SpireSession(string authSessionId)
        //{
        //    string userId;
        //    var authSid = Services.AuthenticationService.SpireAuthenticationSession(authSessionId, out userId);
        //    if (authSid != null) //passed so, store userId in session
        //        SetHttpSession(authSid, userId);
        //    return (authSid != null);
        //}
        private static void SetHttpSession(string authSid, string userId)
        {
            BMWTHttpContext.Current.Session.SetString("auth_AuthenticationSessionId", authSid);
            var user = Services.AuthenticationService.GetUserInfo(userId);
            //BMWTHttpContext.Current.Session.SetObject("ComplexObject", user);

            var userJson = JsonConvert.SerializeObject(user);
            BMWTHttpContext.Current.Session.SetString("auth_User", userJson);
            BMWTHttpContext.Current.Session.SetString("auth_UserId", (user?.user_id ?? userId));
            if (AppSettings.AuthorizationMode == AuthorizationMode.Session) //store auth item code in session
            {
                //var UserAuthorizedItemcodes = Services.AuthenticationService.GetUserAuthorizedItems(userId);
                //var UserAuthorizedItemcodesJson = JsonConvert.SerializeObject(UserAuthorizedItemcodes);
                //BMWTHttpContext.Current.Session.SetString("auth_UserAuthorizedItemcode", UserAuthorizedItemcodesJson);

                //var UserAuthorizedRoles = Services.AuthenticationService.GetUserAuthorizedRoles(userId);
                //var UserAuthorizedRolesJson = JsonConvert.SerializeObject(UserAuthorizedRoles);
                //BMWTHttpContext.Current.Session.SetString("auth_UserAuthorizedRole", UserAuthorizedRolesJson);
            }

            //HttpContext.Current.Session["auth_AuthenticationSessionId"] = authSid;
            //var user = Services.AuthenticationService.GetUserInfo(userId);
            //HttpContext.Current.Session["auth_User"] = user;
            //HttpContext.Current.Session["auth_UserId"] = (user?.Id ?? userId);
            //if (AppSettings.AuthorizationMode == AuthorizationMode.Session) //store auth item code in session
            //{
            //    HttpContext.Current.Session["auth_UserAuthorizedItemcode"] = Services.AuthenticationService.GetUserAuthorizedItems(userId);
            //    HttpContext.Current.Session["auth_UserAuthorizedRole"] = Services.AuthenticationService.GetUserAuthorizedRoles(userId);
            //}
        }
        public static void Logout(bool deleteSessionFromDb = true)
        {
            string authSid = AuthenticationSessionId;
            //if (deleteSessionFromDb && authSid != null) //delete session from db
            //    Services.AuthenticationService.DeleteAuthenticationSession(authSid);

            BMWTHttpContext.Current.Session.Remove("Token");
            BMWTHttpContext.Current.Session.Remove("auth_AuthenticationSessionId");
            BMWTHttpContext.Current.Session.Remove("auth_User");
            BMWTHttpContext.Current.Session.Remove("auth_UserId");
            if (AppSettings.AuthorizationMode == AuthorizationMode.Session) //store auth item code in session
            {
                BMWTHttpContext.Current.Session.Remove("auth_UserAuthorizedItemcode");
                BMWTHttpContext.Current.Session.Remove("auth_UserAuthorizedRole");
            }

            BMWTHttpContext.Current.Request.Headers.Remove("CUSER");
            BMWTHttpContext.Current.Request.Headers.Remove("GROUPS");

            foreach (var cookie in BMWTHttpContext.Current.Request.Cookies.Keys)
            {
                BMWTHttpContext.Current.Response.Cookies.Delete(cookie);
            }
        }

      
       
       
    
    }
}